#!/bin/bash 
echo "" > raw_data.txt

python3 main3.py
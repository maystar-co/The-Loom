#!/bin/bash 
echo "" > raw_data.txt
echo "" > quora_answer_links.txt
python3 main.py

